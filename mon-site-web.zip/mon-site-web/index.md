---
layout: default
title: Accueil
---

# Bienvenue sur mon site Markdown

Ce site est construit avec Markdown et GitHub Pages.

## Naviguez entre les pages :
- [Page 1](page1.md)
- [Page 2](page2.md)

### Contact
Vous pouvez me contacter à [email@example.com](mailto:email@example.com).
